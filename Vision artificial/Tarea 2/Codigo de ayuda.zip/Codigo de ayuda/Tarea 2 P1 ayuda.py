import cv2 as cv
import os

# Read image
#img = cv.imread(r'C:\Users\gschl\Documents\Uach\I Semestre 2023\ELEP-233\Tareas\Archivos Python\Tarea 2\papagayo.jpg')
img = cv.imread(os.path.dirname(__file__) + '\papagayo.jpg')

num_fil = img.shape[0]
num_col = img.shape[1]

#Borra terminal en windows
os.system('cls')

# Pregunta a usuario vértices de la región a recortar
f1 = int(input("Ingrese la fila del vértice superior izquierdo: "))
c1 = int(input("Ingrese la columna del vértice superior izquierdo: "))
f2 = int(input("Ingrese la fila del vértice inferior derecho: "))
c2 = int(input("Ingrese la columna del vértice inferior derecho: "))

# Comprueba que los datos hayan sido ingresados correctamente
if f1 < 0: f1 = 0
if f1 > num_fil: f1 = num_fil


img_recortada = img[f1:f2,c1:c2,:]

# Showing original image
cv.imshow("Imagen Recortada", img_recortada)
cv.waitKey(0)